package com.example.SimpleBookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleBookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
