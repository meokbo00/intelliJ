package com.example.SimpleBookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleBookstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleBookstoreApplication.class, args);



}
